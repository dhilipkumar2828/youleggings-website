@extends('backend.layouts.master')


@section('content')

    <div class="page-content-wrapper ">

        <div class="container-fluid">

            <div class="row">
                <div class="col-sm-12">
                    <div class="float-right page-breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a>Appearence</a></li>
                            <li class="breadcrumb-item"><a href="{{route('banner.index')}}">Advertisement</a></li>
                            <li class="breadcrumb-item active">Create Advertisement</li>
                        </ol>
                    </div>
                    <h5 class="page-title">Appearence</h5>

                </div>
            </div>
            <div class="card m-b-30 card-body">
                <h4 class="card-title font-20 mt-0">Create Advertisement</h4>
                <a href="{{route('advertisement.index')}}" id="add-btn" style="color: #ffffff;"><i class="fa fa-angle-left"
                        aria-hidden="true"></i> Back</a>

            </div>
            <div class="row">
                <div class="col-md-12">
               
                </div>
                <div class="col-12">
                    <div class="card m-b-30">
                        <div class="card-body">

                            <!-- <h4 class="mt-0 header-title">Textual inputs</h4>
                            <p class="text-muted m-b-30 font-14">Here are examples of <code
                                    class="highlighter-rouge">.form-control</code> applied to each
                                textual HTML5 <code class="highlighter-rouge">&lt;input&gt;</code> <code
                                        class="highlighter-rouge">type</code>.</p> -->


                            <form action="{{route('advertisement.store')}}" method="POST">
                                @csrf
                                <!-- <div class="form-group row">
                                    <label for="example-text-input" class="col-sm-2 col-form-label">Title</label>
                                    <div class="col-sm-10">
                                        <input class="form-control" type="text"  placeholder="Enter Title"
                                            id="example-text-input" name="title" value="{{ old('title') }}">
                                            @if ($errors->has('title'))
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $errors->first('title') }}</strong>
                                                </span>
                                            @endif
                                    </div>
                                </div> -->
                                <!-- <div class="form-group row">
                                    <label for="example-text-input" class="col-sm-2 col-form-label">Link</label>
                                    <div class="col-sm-10">
                                        <input class="form-control" type="text" required placeholder="Enter Redirect Link"
                                            id="example-text-input" name="link" value="{{ old('link') }}">
                                    </div>
                                </div> -->
                                <!-- <div class="form-group row">
                                    <label for="example-text-input" class="col-sm-2 col-form-label">Description</label>
                                    <div class="col-sm-10">
                                        <textarea id="description" class="form-control summernote" type="text" name="description"></textarea>
                                    </div>
                                </div> 

                                 <div class="form-group row">
                                    <label for="example-text-input" class="col-sm-2 col-form-label">Url</label>
                                    <div class="col-sm-10">
                                        <input class="form-control" type="text" required placeholder="Enter Url"
                                            id="example-text-input" name="url" value="{{ old('url') }}">
                                    </div>
                                </div>  -->
                             
                                <div class="form-group row">
                                    <label for="example-text-input" class="col-sm-2 col-form-label">Image</label>
                                    <!-- <img src="assets/images/image.png" class="admin-image"> -->
                                    <div class="col-sm-10">
                                        <div class="input-group">
                                            <span class="input-group-btn">
                                              <a id="lfm" data-input="thumbnail" data-preview="holder" class="btn btn-primary">
                                                <i class="fa fa-picture-o"></i> Choose
                                              </a>
                                            </span>
                                            <input id="thumbnail" class="form-control" type="text" value="{{old('photo')}}" name="photo" required>
                                        </div>
                                        <!--<span class="text-note">*NOTE : Maximum image size must be 1900 x 500</span>                                                                             -->
                                   

                                          <div id="holder" style="margin-top:15px;max-height:100px;"></div>
                                    </div>
                                </div>



                                <!-- {{-- <div class="form-group row">
                                <label for="example-search-input" class="col-sm-2 col-form-label">Status</label>
                                <div class="col-sm-10">
                                    <input class="form-control" type="search" Placeholder="Enter Child Category" id="example-search-input">
                                </div>
                            </div> --}} -->

                               
                                <!-- <div class="form-group row">
                                    <label for="condition" class="col-sm-2 col-form-label">Condition</label>
                                    <div class="col-sm-10">
                                        <select class="form-control" required name='condition'>
                                            <option value="">--Condition--</option>
                                            <option value="banner" {{ old('condition') == 'banner' ? 'selected' : '' }}>Banner</option>

                                            <option value="promo" {{ old('condition') == 'promo1' ? 'selected' : '' }}>Promote</option>
                                        </select>
                                    </div>
                                </div> -->
                                <!-- <div class="form-group row">
                                    <label for="condition" class="col-sm-2 col-form-label">Type</label>
                                    <div class="col-sm-10">
                                        <select class="form-control" name='type'>
                                            <option value="">--Type--</option>
                                            <option value="right" {{ old('condition') == 'right' ? 'selected' : '' }}>Right</option>

                                            <option value="left" {{ old('condition') == 'left' ? 'selected' : '' }}>Left</option>
                                        </select>
                                    </div>
                                </div> -->


<!-- 
                                <div class="form-group row">
                                    <label for="example-text-input" class="col-sm-2 col-form-label" ><span class="text-danger"></span>Descripition</label>
                                    <div class="col-sm-10">
                                        <textarea id="elm1"name="description"
                                            value="{{ old('description') }}" placeholder="40% Off!, Free Shipping">40% Off!, Free Shipping</textarea>
                                    </div>
                                </div> -->
                                <div class="form-group row">
                                    <label for="status" class="col-sm-2 col-form-label">Status</label>
                                    <div class="col-sm-10">
                                        <select class="form-control"  name='status' required>
                                            <option value="">--Status--</option>
                                            <option value="active" {{ old('status') == 'active' ? 'selected' : '' }}>Active</option>

                                            <option value="inactive" {{ old('status') == 'inactive' ? 'selected' : '' }}>Inactive</option>

                                        </select>
                                     
                                    </div>
                                   
                                </div>
                                
                            <div class="form-group row">
                          <label for="Position" class="col-sm-2 col-form-label">Position</label>
                            <div class="col-sm-10">
                    <select id="Position" name="position" class="form-control" required>
            <option value="0">-- 0 --</option>
            <option value="1">Advertisement 1</option>
            <option value="2">Advertisement 2</option>
            <!-- Add more options as needed -->
        </select>
    </div>
</div>
                                
 


                                <div class="d-flex">
                                    <button class="btn btn-primary" type="submit">Submit</button>&nbsp;
                                    <button class="btn btn-secondary" id="reset" type="Reset">Cancel</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div> <!-- end col -->
            </div> <!-- end row -->
        </div><!-- container fluid -->

    </div> <!-- Page content Wrapper -->

@endsection
@section('scripts')

@endsection