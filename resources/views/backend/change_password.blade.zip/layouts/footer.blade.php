<footer class="footer">
    © 2025<b> You Leggings<b>
</footer>
